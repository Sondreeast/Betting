"""
World Cup 2026 AI Betting Assistant — backend
===============================================

A small FastAPI service that:
  1. Holds today's fixtures (seeded below with real Group K / Group L
     matchups and FIFA rankings as of 17 June 2026).
  2. Runs an explainable statistical prediction engine (independent
     Poisson goal model) to estimate 1X2, Over/Under 2.5, and BTTS
     probabilities for each match.
  3. Ranks the resulting picks by model confidence, i.e. "the bets that
     are most possible" across today's slate.
  4. Optionally hands the numbers to an LLM (only if OPENAI_API_KEY is
     set) to write a plain-language rationale on top of the math. With
     no key set, it falls back to a template-generated rationale, so the
     whole thing runs out of the box with zero paid API dependencies.

Run it:
    pip install -r requirements.txt
    python main.py
    open http://127.0.0.1:8000

Swap in real data:
  Replace the FIXTURES list below with a live call to a provider like
  API-Football, Sportmonks or Sportradar. The engine only needs each
  team's `power_rating` (or richer inputs — see `expected_goals()`) to run.
"""

import math
import os
from datetime import date
from typing import Dict, List, Optional

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

APP_DIR = os.path.dirname(os.path.abspath(__file__))
FRONTEND_DIR = os.path.normpath(os.path.join(APP_DIR, "..", "frontend"))

app = FastAPI(title="World Cup 2026 AI Betting Assistant", version="1.0.0")


# ---------------------------------------------------------------------------
# 1. Data models
# ---------------------------------------------------------------------------

class TeamStats(BaseModel):
    name: str
    code: str
    flag: str
    power_rating: float = Field(..., description="0-100 composite strength index")
    fifa_rank: Optional[int] = None
    form_note: str = ""


class Fixture(BaseModel):
    id: str
    group: str
    date: str
    venue: str
    kickoff_local: str
    home: TeamStats
    away: TeamStats


class OutcomeProbabilities(BaseModel):
    home_win: float
    draw: float
    away_win: float
    over_2_5: float
    under_2_5: float
    btts_yes: float
    btts_no: float
    most_likely_score: str


class BettingPick(BaseModel):
    market: str
    selection: str
    confidence: float
    risk_level: str
    rationale: str


class MatchPrediction(BaseModel):
    fixture_id: str
    matchup: str
    expected_goals: Dict[str, float]
    probabilities: OutcomeProbabilities
    best_pick: BettingPick
    all_picks: List[BettingPick]
    engine: str


# ---------------------------------------------------------------------------
# 2. Seed data — real Group K & Group L fixtures, 17 June 2026
#
# power_rating is a simplified 0-100 composite built from the June 2026
# FIFA World Ranking (England #4 / 1825.97 pts, Portugal #5 / 1763.83,
# Croatia #11 / 1717.07, Colombia #13 / 1693.09 — exact points) plus
# pre-tournament form reporting for sides outside the ranked top tier
# (DR Congo #56, Uzbekistan #50, Ghana #73, Panama unranked top-60).
# These are illustrative inputs for the demo engine, not an official
# FIFA metric — wire in a live ratings feed for production use.
# ---------------------------------------------------------------------------

def team(name, code, flag, rating, rank=None, note=""):
    return TeamStats(name=name, code=code, flag=flag, power_rating=rating, fifa_rank=rank, form_note=note)


PORTUGAL = team("Portugal", "POR", "🇵🇹", 87, 5, "Ronaldo-led attack, pot-1 seed, heavy Group K favorites")
DRCONGO = team("DR Congo", "COD", "🇨🇩", 40, 56, "First World Cup since 1974, knocked out Cameroon & Nigeria in playoffs")
ENGLAND = team("England", "ENG", "🏴", 90, 4, "Kane, Bellingham, Rice — several pundits' dark-horse pick to win it all")
CROATIA = team("Croatia", "CRO", "🇭🇷", 78, 11, "2018 runners-up, perennial knockout-stage overachievers")
UZBEKISTAN = team("Uzbekistan", "UZB", "🇺🇿", 36, 50, "Tournament debut, squad mostly plays in the domestic league")
COLOMBIA = team("Colombia", "COL", "🇨🇴", 76, 13, "Luis Díaz leads the attack, tipped to handle the US summer heat well")
GHANA = team("Ghana", "GHA", "🇬🇭", 56, 73, "Won just 1 of last 7, coach sacked in March, missing injured Kudus")
PANAMA = team("Panama", "PAN", "🇵🇦", 52, None, "Unbeaten through qualifying, still chasing a first-ever World Cup win")

FIXTURES: List[Fixture] = [
    Fixture(id="k1-por-cod", group="Group K", date="2026-06-17",
            venue="NRG Stadium, Houston", kickoff_local="13:00 local",
            home=PORTUGAL, away=DRCONGO),
    Fixture(id="l1-eng-cro", group="Group L", date="2026-06-17",
            venue="AT&T Stadium, Arlington", kickoff_local="16:00 local",
            home=ENGLAND, away=CROATIA),
    Fixture(id="l1-gha-pan", group="Group L", date="2026-06-17",
            venue="BMO Field, Toronto", kickoff_local="19:00 local",
            home=GHANA, away=PANAMA),
    Fixture(id="k1-uzb-col", group="Group K", date="2026-06-17",
            venue="Estadio Azteca, Mexico City", kickoff_local="22:00 local",
            home=UZBEKISTAN, away=COLOMBIA),
]


# ---------------------------------------------------------------------------
# 3. Prediction engine — independent Poisson goal model
#
# Each team's power rating is converted into an expected-goals (xG) value
# via a rating ratio raised to a damping exponent, then the full score-grid
# Poisson distribution is summed to get 1X2 / Over-Under / BTTS probabilities.
# This is the same family of model used by most public football-prediction
# tools (e.g. the classic Dixon-Coles approach), simplified for clarity.
# ---------------------------------------------------------------------------

BASE_GOALS = 1.35       # average goals per side in a competitive international match
RATING_EXPONENT = 0.75  # damping factor so rating gaps don't blow up xG
MAX_GOALS = 8           # grid size for the Poisson summation


def poisson_pmf(k: int, lam: float) -> float:
    return (lam ** k) * math.exp(-lam) / math.factorial(k)


def expected_goals(home: TeamStats, away: TeamStats) -> Dict[str, float]:
    ratio = home.power_rating / away.power_rating
    scaled = ratio ** RATING_EXPONENT
    return {
        "home": round(BASE_GOALS * scaled, 2),
        "away": round(BASE_GOALS / scaled, 2),
    }


def risk_level(p: float) -> str:
    if p >= 60:
        return "Low"
    if p >= 45:
        return "Medium"
    return "High"


def run_engine(fixture: Fixture) -> MatchPrediction:
    xg = expected_goals(fixture.home, fixture.away)
    lam_h, lam_a = xg["home"], xg["away"]

    home_win = draw = away_win = 0.0
    over_2_5 = btts_yes = 0.0
    best_score, best_score_p = (0, 0), 0.0

    for i in range(MAX_GOALS + 1):
        p_i = poisson_pmf(i, lam_h)
        for j in range(MAX_GOALS + 1):
            p = p_i * poisson_pmf(j, lam_a)
            if i > j:
                home_win += p
            elif i == j:
                draw += p
            else:
                away_win += p
            if i + j > 2.5:
                over_2_5 += p
            if i >= 1 and j >= 1:
                btts_yes += p
            if p > best_score_p:
                best_score_p, best_score = p, (i, j)

    probs = OutcomeProbabilities(
        home_win=round(home_win * 100, 1),
        draw=round(draw * 100, 1),
        away_win=round(away_win * 100, 1),
        over_2_5=round(over_2_5 * 100, 1),
        under_2_5=round((1 - over_2_5) * 100, 1),
        btts_yes=round(btts_yes * 100, 1),
        btts_no=round((1 - btts_yes) * 100, 1),
        most_likely_score=f"{best_score[0]}-{best_score[1]}",
    )

    candidates = [
        ("1X2", f"{fixture.home.name} to win", probs.home_win),
        ("1X2", "Draw", probs.draw),
        ("1X2", f"{fixture.away.name} to win", probs.away_win),
        ("Total goals", "Over 2.5 goals", probs.over_2_5),
        ("Total goals", "Under 2.5 goals", probs.under_2_5),
        ("Both teams to score", "Yes", probs.btts_yes),
        ("Both teams to score", "No", probs.btts_no),
    ]
    candidates.sort(key=lambda c: c[2], reverse=True)

    def rationale(selection: str, p: float) -> str:
        return (
            f"Model expects a {lam_h:.2f}-{lam_a:.2f} scoreline from power ratings of "
            f"{fixture.home.name} {fixture.home.power_rating} vs {fixture.away.name} "
            f"{fixture.away.power_rating}, putting '{selection}' at {p}% probability."
        )

    picks = [
        BettingPick(market=m, selection=s, confidence=p, risk_level=risk_level(p), rationale=rationale(s, p))
        for (m, s, p) in candidates[:5]
    ]

    return MatchPrediction(
        fixture_id=fixture.id,
        matchup=f"{fixture.home.name} vs {fixture.away.name}",
        expected_goals=xg,
        probabilities=probs,
        best_pick=picks[0],
        all_picks=picks,
        engine="poisson-v1",
    )


def llm_enhance(prediction: MatchPrediction) -> Optional[str]:
    """Optional: rewrite the top pick's rationale in natural language via an LLM.
    Only runs if OPENAI_API_KEY is set in the environment; otherwise the
    template-based rationale from run_engine() is used as-is."""
    if not os.environ.get("OPENAI_API_KEY"):
        return None
    try:
        from langchain_openai import ChatOpenAI
        llm = ChatOpenAI(model="gpt-4o", temperature=0.3)
        prompt = (
            "You are a football data analyst. In 2-3 plain-language sentences, explain why "
            f"a statistical model favors '{prediction.best_pick.selection}' "
            f"({prediction.best_pick.confidence}% probability) for {prediction.matchup}, given "
            f"expected goals {prediction.expected_goals}. End by noting this is a statistical "
            "estimate, not a guarantee."
        )
        response = llm.invoke(prompt)
        return response.content.strip()
    except Exception:
        return None


# ---------------------------------------------------------------------------
# 4. API routes
# ---------------------------------------------------------------------------

DISCLAIMER = (
    "Model output is a statistical estimate for analysis purposes, not betting advice "
    "or a guarantee of results. Odds and outcomes always carry risk of loss — bet only "
    "what you can afford to lose, and note that gambling-advertising and licensing rules "
    "vary by country."
)


@app.get("/api/fixtures")
async def get_fixtures():
    return {"date": str(date.today()), "fixtures": FIXTURES}


@app.get("/api/predict/{fixture_id}", response_model=MatchPrediction)
async def predict(fixture_id: str):
    fixture = next((f for f in FIXTURES if f.id == fixture_id), None)
    if not fixture:
        raise HTTPException(status_code=404, detail="Fixture not found")
    prediction = run_engine(fixture)
    enhanced = llm_enhance(prediction)
    if enhanced:
        prediction.best_pick.rationale = enhanced
    return prediction


@app.get("/api/predictions/today")
async def predictions_today():
    """The 'most likely' bets across all of today's fixtures, ranked by model confidence."""
    results = []
    for fixture in FIXTURES:
        prediction = run_engine(fixture)
        results.append({"fixture": fixture, "prediction": prediction})
    results.sort(key=lambda r: r["prediction"].best_pick.confidence, reverse=True)
    return {"date": str(date.today()), "disclaimer": DISCLAIMER, "results": results}


@app.post("/api/predict-custom", response_model=MatchPrediction)
async def predict_custom(home: TeamStats, away: TeamStats):
    """Run the engine on any custom matchup — plug live stats in here."""
    fixture = Fixture(id="custom", group="Custom", date=str(date.today()),
                       venue="", kickoff_local="", home=home, away=away)
    return run_engine(fixture)


# ---------------------------------------------------------------------------
# 5. Serve the frontend
# ---------------------------------------------------------------------------

@app.get("/")
async def index():
    return FileResponse(os.path.join(FRONTEND_DIR, "index.html"))

app.mount("/static", StaticFiles(directory=FRONTEND_DIR), name="static")


if __name__ == "__main__":
    import uvicorn
    port = int(os.environ.get("PORT", 8000))
    host = "0.0.0.0" if os.environ.get("PORT") else "127.0.0.1"
    uvicorn.run("main:app", host=host, port=port, reload=False)
